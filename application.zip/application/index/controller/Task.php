<?php

namespace app\index\controller;


use think\Controller;
class Task extends Controller{

	

    public function index(){



       //加载模板

    	return view();

    }

}

