<?php
	header("Location:/public/");
?>